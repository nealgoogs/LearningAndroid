package com.example.homework3

data class Cats(val name: String, var rating: Float, val catImage: String)